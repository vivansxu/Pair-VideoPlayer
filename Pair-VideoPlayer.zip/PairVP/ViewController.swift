//
//  ViewController.swift
//  PairVP
//
//  Created by liwen xu on 2018/11/10.
//  Copyright © 2018年 liwen xu. All rights reserved.
//

import UIKit
import AVKit
import CallKit
import Alamofire

class ViewController: UIViewController {

    var id = 0 as Int
    @IBOutlet weak var MyID: UILabel!
    
    @IBOutlet weak var UserInput: UITextField!
    
    @IBOutlet weak var PeerID: UITextField!
    @IBAction func VPButtonAction(_ sender: Any) {
        let inputURL = URL(string: UserInput.text!)
        let video = AVPlayer(url: inputURL!)
        let videoPlayer = AVPlayerViewController()
        videoPlayer.player = video
        
        present(videoPlayer, animated: true, completion: {
            video.pause()
            //let interval = CMTime(seconds: 0.5, preferredTimescale: 25)
            //let mainqueue = DispatchQueue.main
            //let timeObserverToken =
                //video.addPeriodicTimeObserver(forInterval: interval, queue: mainqueue) {
                   // [weak self] time in
                    // update player transport UI
            //}
            /*if (video.currentTime().seconds == 0.00) {
                let setTime = CMTime.init(seconds: 33.33, preferredTimescale: 25)
                video.seek(to: setTime)
            }*/
        })
        var last_rate = 0.0 as Float
        
        
        var peerid = Int(PeerID.text!)
        var isModified = false
        print(peerid ?? 0)
        
        _ = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { timer in
            let play_rate = video.rate
            if (play_rate != last_rate && isModified == false) {
                let playtime = video.currentTime().seconds
                print("\n\n\n\n\n\n\n\n\n\n\(playtime)\n\n\n\n\n\n\n\n\n\n")
                if (play_rate > 0.5) {
                    Alamofire.request("http://47.107.155.242:81/playstate", parameters: ["state":"play","time":playtime,"myid":self.id,"peerid":peerid]).responseJSON { response in
                        print(response.result)
                    }
                    
                } else {
                    Alamofire.request("http://47.107.155.242:81/playstate", parameters: ["state":"stop","time":playtime,"myid":self.id,"peerid":peerid]).responseJSON { response in
                        print(response.result)
                    }
                    
                }
                last_rate = play_rate
            } else if (play_rate != last_rate && isModified == true) {
                isModified = false
                last_rate = play_rate
            }
            Alamofire.request("http://47.107.155.242:81/pulse", parameters: ["myid":self.id]).responseJSON { response in
                switch(response.result) {
                case .success(let JSON):
                    let response = JSON as! NSDictionary
                    let status = response.object(forKey: "updated")!
                    if (status as! String == "true") {
                        let seconds = response.object(forKey: "seconds")!
                        if ((seconds as! Double) < 0.0) {
                            video.pause()
                            isModified = true
                        } else {
                            var setTime = CMTime.init(seconds: seconds as! Double, preferredTimescale: 25)
                            video.seek(to: setTime)
                            video.play()
                            isModified = true
                        }
                    }
                case .failure(let error):
                    print(error)
                }
            }
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        Alamofire.request("http://47.107.155.242:81/getid").responseJSON { response in
            switch(response.result) {
            case .success(let JSON):
                let response = JSON as! NSDictionary
                let userID = response.object(forKey: "id")!
                print(userID)
                self.id = userID as! Int
                print(self.id)
                self.MyID.text = String(describing: "My ID: \(userID)")
            case .failure(let error):
                print(error)
            }
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}

